
export default function Home() {
  return (
    <div style={{ minHeight: '100vh', backgroundColor: '#f0fdf4', padding: '1.5rem', color: '#1f2937' }}>
      <header style={{ textAlign: 'center', marginBottom: '2.5rem' }}>
        <h1 style={{ fontSize: '2.5rem', fontWeight: 'bold' }}>BODY FORMULA</h1>
        <p style={{ fontSize: '1.125rem', marginTop: '0.5rem' }}>
          Центр здоров'я та догляду за тілом / Center for Health & Body Care / Центр здоровья и ухода за телом
        </p>
      </header>

      <section style={{ display: 'grid', gap: '1.5rem' }}>
        <div style={{ background: '#fff', padding: '1rem', borderRadius: '0.5rem' }}>
          <h2 style={{ fontSize: '1.25rem', fontWeight: '600' }}>Про нас / About Us / О нас</h2>
          <p>
            BODY FORMULA — це сучасний центр здоров'я, де ви можете пройти персональні процедури з корекції фігури,
            гінекологічні консультації, масаж і відновлювальні практики. BODY FORMULA is a modern health center where you
            can receive personalized body shaping procedures, gynecological consultations, massage, and restorative
            treatments. BODY FORMULA — это современный центр здоровья, где вы можете пройти персональные процедуры по
            коррекции фигуры, гинекологические консультации, массаж и восстановительные практики.
          </p>
        </div>

        <div style={{ background: '#fff', padding: '1rem', borderRadius: '0.5rem' }}>
          <h2 style={{ fontSize: '1.25rem', fontWeight: '600' }}>Послуги / Services / Услуги</h2>
          <ul>
            <li>Корекція фігури / Body shaping / Коррекция фигуры</li>
            <li>Гінекологічні консультації / Gynecological consultations / Гинекологические консультации</li>
            <li>Лімфодренажний масаж / Lymphatic massage / Лимфодренажный массаж</li>
            <li>Загальна діагностика / General diagnostics / Общая диагностика</li>
          </ul>
        </div>

        <div style={{ background: '#fff', padding: '1rem', borderRadius: '0.5rem' }}>
          <h2 style={{ fontSize: '1.25rem', fontWeight: '600' }}>Записатися / Book an Appointment / Записаться</h2>
          <form style={{ display: 'grid', gap: '1rem' }}>
            <input placeholder="Ім'я / Name / Имя" />
            <input placeholder="Телефон / Phone / Телефон" />
            <textarea placeholder="Послуга або коментар / Service or comment / Услуга или комментарий" />
            <button style={{ padding: '0.5rem', background: '#4ade80', border: 'none', borderRadius: '0.25rem' }}>
              Надіслати / Submit / Отправить
            </button>
          </form>
        </div>

        <div style={{ background: '#fff', padding: '1rem', borderRadius: '0.5rem', textAlign: 'center' }}>
          <p>
            Зв'яжіться з нами через Telegram або WhatsApp / Contact us via Telegram or WhatsApp / Свяжитесь с нами через Telegram или WhatsApp
          </p>
          <p style={{ marginTop: '0.5rem' }}>@bodyformula_clinic</p>
        </div>
      </section>
    </div>
  );
}
